
import { handleGetProductLocalStorage, setInLocalstorage } from "./src/persistence/localstorage.js";
import { renderCategorias } from "./src/services/categories.js";
import { handleGetProductsToStore } from "./src/views/store.js";
import "./style.css";

//==== APLICACOIN ====//

handleGetProductsToStore()

renderCategorias();

/* --- product --- */

const buttonAdd = document.getElementById("buttonAddElement");

buttonAdd.addEventListener("click",()=>{
    openModal();
})


/* --- POPUP --- */

const buttonCancel = document.getElementById("cancelButton")
buttonCancel.addEventListener("click",()=>{
    handleCancelButton();
})

const handleCancelButton = () => {
    closeModal();
}
/* --- FUNCIONES ABRIR Y CERRAR MODAL */

const openModal = () => {
    const modal = document.getElementById("modalPopUp")
    modal.style.display = "flex"
}

const closeModal = () => {
    const modal = document.getElementById("modalPopUp")
    modal.style.display = "none"
};


/* --- GUARDAR O MODIFICAR ELEMENTOS */

const acceptButton = document.getElementById("acceptButton")
acceptButton.addEventListener("click", ()=>{
    handleSaveOrModifyElements();
})


const handleSaveOrModifyElements = () =>{
    const nombre = document.getElementById("nombre").value,
    imagen = document.getElementById("img").value,
    precio = document.getElementById("precio").value,
    categoria = document.getElementById("categoria").value;
    
    let object = {
        id: new Date().toISOString(),
        nombre,
        imagen,
        precio,
        categoria,
    }

    setInLocalstorage(object);
    //closeModal();
}





