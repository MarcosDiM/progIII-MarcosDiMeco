// === STORE ==== //

import { handleGetProductLocalStorage } from "../persistence/localstorage"

export const handleGetProductsToStore = () => {

    const products =  handleGetProductLocalStorage()
    console.log(products);
    handleRenderList(products);
}


export const handleRenderList = (productosIn) =>{

    const burgers = productosIn.filter((el) => el.categories == "Hamburguesas")
    const gaseosas = productosIn.filter((el) => el.categories == "Gaseosas")
    const papas = productosIn.filter((el) => el.categories == "Papas")



    const renderProductGroup = (productos, title) => {
        if(
            productos.length>0
        ){
            const productosHTML = productos.map((producto, index)=>{
                return`<div>
                <div>
                <img src=${producto.imagenes} />
                <div>
                <h2>${producto.nombre}</h2>
                </div>
                <div>
                <p><b>Precio: </b> $ ${producto.precio}</p>
                <p><b>Categoria: </b> $ ${producto.categoria}</p>
                </div>
                </div>
                </div>`
            })
            return `
            <section>
            <h3>${title}</h3>
            <div>
            ${productosHTML.join("")}
            </div>

            </section>
            `
        } else {
            return ""
        }
    }

    //renderizar cada uno de los productos dentro de su categoria 
    const appContainer = document.getElementById("storeContainer");
    appContainer.innerHTML = `
    ${renderProductGroup(burgers,"Hamburger")}
    ${renderProductGroup(papas,"Papas")}
    ${renderProductGroup(gaseosas,"Gaseosas")}
    `
}